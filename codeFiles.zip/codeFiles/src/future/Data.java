package future;

public interface Data {
	public abstract String getContent();
}
